INDONESIAN LANGUAGE
JIKA ANDA MENGGUNAKAN PROXY LIST SILAHKAN OPEN FILE 'settings.php' di dalam folder function

 - install php di PC atau Laptop kalian (caranya banyak di google)
 - sett up enviroment variable PHP (caranya di google banyak)
 - open file 'open.bat'
 - ENJOY :)

mode_proxy = on [untuk menggunakan proxy]
mode_proxy = off [tidak menggunakan proxy]
proxy_list = proxy.txt [nama file proxy anda]
proxy_pwd = 'isi password proxy anda' [jika proxy anda menggunakan password silahkan isi jika tidak biarkan kosong]

===================================================================================================

ENGLISH LANGUAGE
IF YOU ARE USING A PROXY LIST PLEASE OPEN FILE 'settings.php' in the function folder

 - install php on your PC or Laptop (there are many ways on Google)
 - set up the PHP environment variable (there are many ways on Google)
 - open file 'open.bat'
 - ENJOY :)

mode_proxy = on [to use proxy]
mode_proxy = off [no use proxy]
proxy_list = proxy.txt [name of your proxy file]
proxy_pwd = 'fill in your proxy password' [if your proxy uses a password please fill in otherwise leave blank]